//
//  ListViewController.swift
//  Iven
//
//  Created by Adam Moreno on 12/18/18.
//  Copyright © 2018 Snap On Tool. All rights reserved.
//

import UIKit
import Firebase

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var listTableView: UITableView!
    @IBOutlet weak var listHeaderLabel: UILabel!
    
    private var ref:DatabaseReference!
    private var itemArray = [Items]()
    private var so = LogInViewController()
    
    private var selectedCPU:String!
    private var selectedItem:String!
    private var selectedUnits:String!
    private var selectedPPU:String!
    public var userEmail:String!
    private var userRef:String!
    
    override func viewWillAppear(_ animated: Bool) {
        //getItems()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        listHeaderLabel.backgroundColor = UIColor(patternImage: UIImage(named: "LOGO")!)
        userRef = userEmail.replacingOccurrences(of: ".", with: ",")
        print(userRef)
        getItems()
        self.listTableView.addSubview(self.refreshControl)
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(itemArray.count)
        return itemArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let list = tableView.dequeueReusableCell(withIdentifier: "inventoryCell", for: indexPath) as! ListTableViewCell
        
        list.listUPC.text? = itemArray[indexPath.row].getBarcode()
        list.listItem.text? = itemArray[indexPath.row].getItem()
        list.listUnits.text? = itemArray[indexPath.row].getUnits()
        list.listPPU.text? = itemArray[indexPath.row].getPPU()
        
        return list
    
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedCPU = itemArray[indexPath.row].getBarcode()
        selectedItem = itemArray[indexPath.row].getItem()
        selectedUnits = itemArray[indexPath.row].getUnits()
        selectedPPU = itemArray[indexPath.row].getPPU()
        self.performSegue(withIdentifier: "list2Review", sender: nil)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "list2Review"){
            let review = segue.destination as! ReviewViewController
            review.upc = selectedCPU
            review.product = selectedItem
            review.qty = selectedUnits
            review.price = selectedPPU
            review.reviewEmail = userRef
        }
    }
    
    public func getItems(){
        ref = Database.database().reference(withPath: userRef).child("ITEMS")
        ref.observe(DataEventType.value, with: {(snapshot) in
            if snapshot.childrenCount > 0 {
                
                self.itemArray.removeAll()
                
                for itemInList in snapshot.children.allObjects as! [DataSnapshot]
                {
                    let item = itemInList.value as! [String:AnyObject]
                    let readBarcode = item["Barcode"] as! String
                    let readItem = item["Item"] as! String
                    let readUnits = item["Units"] as! String
                    let readPPU = item["PPU"] as! String
                    print(readBarcode)
                    let addItem = Items(barcode: readBarcode, item: readItem, units: readUnits, ppu: readPPU)
                    
                    print(addItem)
                    
                    self.itemArray.append(addItem)
                }
            }
            self.listTableView.reloadData()
        })
    }
    
    @IBAction func unwindToHome(_ unwindSegue: UIStoryboardSegue) {
        // Use data from the view controller which initiated the unwind segue
    }
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(ListViewController.handleRefresh(_:)), for: UIControl.Event.valueChanged)
        refreshControl.tintColor = UIColor.red
        
        return refreshControl
    }()
    
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        // Do some reloading of data and update the table view's data source
        // Fetch more objects from a web service, for example...
        
        // Simply adding an object to the data source for this example
        getItems()
        
        self.listTableView.reloadData()
        refreshControl.endRefreshing()
    }
    
    @IBAction private func signUserOut(){
        so.signOut()
    }

}
