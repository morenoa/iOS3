//
//  LogInViewController.swift
//  Iven
//
//  Created by Adam Moreno on 12/18/18.
//  Copyright © 2018 Snap On Tool. All rights reserved.
//

import UIKit
import Firebase

class LogInViewController: UIViewController {

    @IBOutlet weak var userEmail: UITextField!
    @IBOutlet weak var userPassword: UITextField!
    
    private var authEmail:String!
    private var authPass:String!
    
    private var handle:Auth!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userPassword.text = "123456"
        userEmail.text = "eddy@gmail.com"
        // Do any additional setup after loading the view.
    }
    
    private func signInUser(){
        if let passward = userPassword.text, let email = userEmail.text
        {
            Auth.auth().signIn(withEmail: email, password: passward) { (user, error) in
                if let error = error
                {
                    self.alertMessege(messege: error.localizedDescription)
                }
                self.performSegue(withIdentifier: "login2List", sender: nil)
            }
        }
    }
    
    public func signOut(){
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
    }
    
    @IBAction func signIn(){
        signInUser()
    }
    
    @IBAction func createAccount(){
        
    }
    
    @IBAction func unwindToLogin(_ unwindSegue: UIStoryboardSegue) {
        userPassword.text = nil
        userEmail.text = nil
        userPassword.placeholder = "Password"
        userEmail.placeholder = "Email"
        // Use data from the view controller which initiated the unwind segue
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    private func alertMessege(messege:String){
        let alert:UIAlertController = UIAlertController(title: "WARNING!", message: messege, preferredStyle: .alert)
        let action:UIAlertAction = UIAlertAction(title: "OK", style: .default){
            (_:UIAlertAction) in
            return
        }
        
        alert.addAction(action)
        self.present(alert, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "login2List"
        {
            let tabBar = segue.destination as! UITabBarController
            let list = tabBar.viewControllers?[0] as! ListViewController
            list.userEmail = userEmail.text
        }
    }
    
    

}
