//
//  ReviewViewController.swift
//  FirebaseCore
//
//  Created by Adam Moreno on 12/18/18.
//

import UIKit

class ReviewViewController: UIViewController {
    
    @IBOutlet weak var itemBarcode: UILabel!
    @IBOutlet weak var itemDescription: UILabel!
    @IBOutlet weak var itemUnits: UILabel!
    @IBOutlet weak var itemPPU: UILabel!
    @IBOutlet weak var reviewHeaderLabel: UILabel!
    
    public var upc:String!
    public var product:String!
    public var qty:String!
    public var price:String!
    private var reviewUserRef: String!
    public var reviewEmail: String!
    
    private var writeDatabase = WriteDatabase()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        reviewHeaderLabel.backgroundColor = UIColor(patternImage: UIImage(named: "LOGO")!)
        
        reviewUserRef = reviewEmail
        print("\(reviewUserRef) user ref email")
        itemBarcode.text! = upc
        itemDescription.text! = product
        itemUnits.text! = qty
        itemPPU.text! = price

        // Do any additional setup after loading the view.
    }
    
    @IBAction func editInventory(_ sender: Any){
        // segue to edit view controller
        performSegue(withIdentifier: "review2AddEdit", sender: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "review2AddEdit"){
            let AE = segue.destination as! AddEditViewController
            AE.AEEmail = reviewUserRef
            AE.AEBarcode = upc
            AE.AEDiscription = product
            AE.AEQTT = qty
            AE.AEPrice = price
            AE.myQ = 1
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    

}
