//
//  ReadDatabase.swift
//  Iven
//
//  Created by Adam Moreno on 12/18/18.
//  Copyright © 2018 Snap On Tool. All rights reserved.
//

import Foundation
import Firebase

class ReadDatabase{
    
    private var ref:DatabaseReference!
    
    public var itemObject = [Items]()
    public var userObject = [Users]()
    
    public func fetchItems(){
        ref = Database.database().reference().child("ITEMS")
        ref.observe(DataEventType.value, with: {(snapshot) in
            if snapshot.childrenCount > 0 {
                
                self.itemObject.removeAll()
                
                for itemInList in snapshot.children.allObjects as! [DataSnapshot]
                {
                    let item = itemInList.value as! [String:AnyObject]
                    let readBarcode = item["Barcode"] as! String
                    let readItem = item["Item"] as! String
                    let readUnits = item["Units"] as! String
                    let readPPU = item["PPU"] as! String
                    
                    let addItem = Items(barcode: readBarcode, item: readItem, units: readUnits, ppu: readPPU)
                    
                    self.itemObject.append(addItem)
                }
            }
        })
    }
    
    public func fetchUsers(){
        ref = Database.database().reference().child("USERS")
        ref.observe(DataEventType.value, with: {(snapshot) in
            if snapshot.childrenCount > 0 {
                self.userObject.removeAll()
                
                for userInList in snapshot.children.allObjects as! [DataSnapshot]
                {
                    let user = userInList.value as! [String:AnyObject]
                    let fName = user["firstName"] as! String
                    let lName = user["lastName"] as! String
                    let uEmail = user["userEmail"] as! String
                    let uPass = user["userPassword"] as! String
                    
                    let newUser = Users(firstName: fName, lastName: lName, userEmail: uEmail, userPassword: uPass)
                    
                    self.userObject.append(newUser)
                }
            }
        })
    }
    
    public func findItem(code:String) -> Int{
        var found:Int = -1
        for (index,upc) in itemObject.enumerated() {
            if(upc.getBarcode() == code){
                found = index
            }
        }
        return found
    }
    
    public func check4DoubleUser(user:String) -> Int{
        var same:Int = -1
        for (index,userEmail) in userObject.enumerated() {
            if(userEmail.getUserEmail() == user){
                same = index
            }
        }
        return same
    }
    
}
