//
//  WriteDatabase.swift
//  Iven
//
//  Created by Adam Moreno on 12/18/18.
//  Copyright © 2018 Snap On Tool. All rights reserved.
//

import Foundation
import Firebase

class WriteDatabase{
    
    private var ref:DatabaseReference!
    
    private var writeItemObject = [Items]()
    private var writeUserObject = [Users]()
    
    public func writeData(BarCode:String, Item:String, Units:String, PPU:String, emailRef:String){
        ref = Database.database().reference(withPath: "ITEMS").child(emailRef)
        
        ref.child(BarCode).setValue([
            "Barcode": BarCode,
            "Item": Item,
            "Units": Units,
            "PPU": PPU
        ])
    }
    
    public func writeNewUser(firstName:String, lastName:String, userEmail:String, userPassword:String){
        ref = Database.database().reference(withPath: "USERS").child(userEmail)
        
        ref.setValue([
            "firstName": firstName,
            "lastName": lastName,
            "userEmail": userEmail,
            "userPassword": userPassword
            ])
    }
}
