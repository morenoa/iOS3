//
//  Items.swift
//  
//
//  Created by Adam Moreno on 12/18/18.
//

import UIKit

class Items: NSObject {
    
    private var barcode:String!
    private var item:String!
    private var units:String!
    private var ppu:String!
    
    init(barcode:String, item:String, units:String, ppu:String) {
        self.barcode = barcode
        self.item = item
        self.units = units
        self.ppu = ppu
    }
    
    public func getBarcode() -> String{
        return barcode
    }
    
    public func getItem() -> String{
        return item
    }
    
    public func getUnits() -> String{
        return units
    }
    
    public func getPPU() -> String{
        return ppu
    }
    
    public func setBarcode(code:String){
        barcode = code
    }
    
    public func setItem(product:String){
        item = product
    }
    
    public func setUnits(count:String){
        units = count
    }
    
    public func setPPU(price:String){
        ppu = price
    }
    
    convenience override init() {
        self.init(barcode: " ", item: " ", units: " ", ppu: " ")
    }

}
