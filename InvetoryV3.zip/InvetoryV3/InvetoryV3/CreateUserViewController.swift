//
//  CreateUserViewController.swift
//  InvetoryV3
//
//  Created by Adam Moreno on 12/21/18.
//  Copyright © 2018 Snap On Tool. All rights reserved.
//

import UIKit
import Firebase

class CreateUserViewController: UIViewController {
    
    @IBOutlet private weak var firstName: UITextField!
    @IBOutlet private weak var lastName: UITextField!
    @IBOutlet private weak var userEmail: UITextField!
    @IBOutlet private weak var reUserEmail: UITextField!
    @IBOutlet private weak var userPassword: UITextField!
    @IBOutlet private weak var reUserPassword: UITextField!
    
    private var fName:String!
    private var lName:String!
    private var email:String!
    private var reEmail:String!
    private var password:String!
    private var rePassword:String!
    
    private var write = WriteDatabase()

    override func viewDidLoad() {
        super.viewDidLoad()
        firstName.text = "Moreno"
        lastName.text = "Adam"
        userEmail.text = "abeangoalie39@gmail.com"
        reUserEmail.text = "abeangoalie39@gmail.com"
        userPassword.text = "123456"
        reUserPassword.text = "123456"

        // Do any additional setup after loading the view.
    }
    
    @IBAction private func createUser(_ sender:Any){
        fName = firstName.text; lName = lastName.text; email = userEmail.text; reEmail = reUserEmail.text; password = userPassword.text; rePassword = reUserPassword.text;
        let loginInfo = userEmail.text?.replacingOccurrences(of: ".", with: ",")
        let textFieldArray:[String] = [fName,lName,email,reEmail,password,rePassword]
        //checkCreatUserField(userArray:textUserArray) check for empty text field
        let userError = checkEmailPassword(compareArray: textFieldArray)
        //checkEmailPassword(compareFields:compareArray) check if user entered the email and password
        // they want to use
        switch userError {
        case 0:
            //create user's account and segue to list view controller
            if let userName = userEmail.text, let password = userPassword.text
            {
                Auth.auth().createUser(withEmail: userName, password: password) { (authResult, error) in
                    print("\(authResult.debugDescription)")
                    if let error = error
                    {
                        self.alertNewUser(messege: error.localizedDescription)
                        return
                    }
                    self.write.writeNewUser(firstName: self.fName, lastName: self.lName, userEmail: loginInfo!, userPassword: self.password)
                    self.performSegue(withIdentifier: "create2List", sender: nil)
                    
                }
            }
            break
        case 2:
            let emailAlert = "Email does not match!"
            alertNewUser(messege: emailAlert)
            break
        case 3:
            let passwordAlert = "Password does not match!"
            alertNewUser(messege: passwordAlert)
            break
        case 1:
            let emptyAlert = "Not all fields are filled!"
            alertNewUser(messege: emptyAlert)
        default:
            print("do something here. like something. do something. Blah!")
        }
    }
    
//    private func checkCreateUser(userArray:[String]) -> Bool{
//        for newUser in userArray {
//            if(newUser.isEmpty){
//                return false
//            }
//        }
//        return true
//    }
    
    private func checkEmailPassword(compareArray:[String]) -> Int {
        
        for newUser in compareArray {
            if(newUser.isEmpty)
            {
                return 1
            }
        }
        
        if (compareArray[2] != compareArray[3])
        {
            return 2
        }
        
        if (compareArray[4] != compareArray[5])
        {
            return 3
        }
        return 0
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    private func alertNewUser(messege:String){
        let alert:UIAlertController = UIAlertController(title: "ATTENTION!", message: messege, preferredStyle: .alert)
        let action:UIAlertAction = UIAlertAction(title: "OK", style: .default){
            (_:UIAlertAction) in
            return
        }
        
        alert.addAction(action)
        self.present(alert,animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "create2List")
        {
            let tabBar = segue.destination as! UITabBarController
            let list = tabBar.viewControllers?[0] as! ListViewController
            list.userEmail = userEmail.text
        }
    }

}
