//
//  Users.swift
//  InvetoryV3
//
//  Created by Adam Moreno on 12/21/18.
//  Copyright © 2018 Snap On Tool. All rights reserved.
//

import UIKit

class Users: NSObject {
    
    private var firstName:String!
    private var lastName:String!
    private var userEmail:String!
    private var userPassword:String!
    
    init(firstName:String, lastName:String, userEmail:String, userPassword:String) {
        self.firstName = firstName
        self.lastName = lastName
        self.userEmail = userPassword
        self.userPassword = userPassword
    }
    
    public func getFirstName() -> String{
        return firstName
    }
    
    public func getLastName() -> String{
        return lastName
    }
    
    public func getUserEmail() -> String{
        return userEmail
    }
    
    public func getUserPassword() -> String{
        return userPassword
    }
    
    public func setFirstName(first:String){
        firstName = first
    }
    
    public func setLastName(last:String){
        lastName = last
    }
    
    public func setUserEmail(email:String){
        userEmail = email
    }
    
    convenience override init() {
        self.init(firstName: " ", lastName: " ", userEmail: " ", userPassword: " ")
    }

}
