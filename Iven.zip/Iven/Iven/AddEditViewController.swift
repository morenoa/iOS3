//
//  AddEditViewController.swift
//  Iven
//
//  Created by Adam Moreno on 12/18/18.
//  Copyright © 2018 Snap On Tool. All rights reserved.
//

import UIKit

class AddEditViewController: UIViewController {
    
    @IBOutlet weak var AEUPC: UILabel!
    @IBOutlet weak var AEItem: UITextField!
    @IBOutlet weak var AEUnits: UITextField!
    @IBOutlet weak var AEPPU: UITextField!
    
    public var AEBarcode:String = " "
    public var AEDiscription:String = " "
    public var AEQTT:String = " "
    public var AEPrice:String = " "
    public var myQ:Int!
    
    private var writeInven = WriteDatabase()

    override func viewDidLoad() {
        super.viewDidLoad()
        switch myQ {
        case 1:
            AEUPC.text? = AEBarcode
            AEItem.text? = AEDiscription
            AEUnits.text? = AEQTT
            AEPPU.text? = AEPrice
            break
        case 0:
            AEUPC.text? = AEBarcode
            break
        default:
            print("do something")
        }

        // Do any additional setup after loading the view.
    }
    
    @IBAction func add2Database(_ sender:Any){
        let addCPU:String = AEUPC.text!
        let addItem:String = AEItem.text!
        let addUnits:String = AEUnits.text!
        let addPPU:String = AEPPU.text!
        
        let textFieldArray:[String] = [addPPU,addItem,addUnits]
        
        if(checkField(fieldArray: textFieldArray)){
            writeInven.writeData(BarCode: addCPU, Item: addItem, Units: addUnits, PPU: addPPU)
            alertUser()
        }
        else{
            alertMessege()
        }
       
    }
    
    private func alertUser(){
        let alert:UIAlertController = UIAlertController(title: "Success", message: "Item has been added to your Inventory!", preferredStyle: .alert)
        
        let action:UIAlertAction = UIAlertAction(title: "OK", style: .default) {
            (_:UIAlertAction) in
            // unwind back to list view controller
             self.performSegue(withIdentifier: "addEdit2List", sender: self)
            
            }
        
        alert.addAction(action)
        self.present(alert, animated: true)
    }
    
    private func checkField(fieldArray:[String]) -> Bool{
        for textArray in fieldArray {
            print(textArray)
            if textArray == ""{
                return false
            }
        }
        return true
    }
    
    private func alertMessege(){
        let alert:UIAlertController = UIAlertController(title: "WARNING", message: "Please fill in all text field.", preferredStyle: .alert)
        let action:UIAlertAction = UIAlertAction(title: "OK", style: .default){
            (_:UIAlertAction) in
            return
        }
        
        alert.addAction(action)
        self.present(alert, animated: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
